package desen;


import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JPanel;
import javax.swing.Timer;



public class animationPanel extends JPanel {
    
        	
		private BufferedImage img;
		private int x=0;
		private int y=0;
		private int direction=1;

	    public animationPanel() {
	    	 
	    	    
	        try {
	        	 
	            img = ImageIO.read(new File("C:/Users/Diana/Desktop/Animation/src/desen/1.jpg"));
	        	Timer timer = new Timer(100, new ActionListener() {
	                @Override
	                public void actionPerformed(ActionEvent e) {
	                	
	                
	                    repaint();
	                }
	            });
	            timer.start();
	        } catch (IOException ex) {
	            ex.printStackTrace();
	        }
	    }
	    @Override
	    public Dimension getPreferredSize() {
	        return img == null ? super.getPreferredSize() : new Dimension(4000,img.getHeight());
	    }
	    @Override
	    public void paintComponent(Graphics g) {
	    	super.paintComponent(g);
	        Graphics2D g2 = (Graphics2D) g;
	        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
	        x = x + 50 * direction;
        	if (x < 0 || x >= 1900-img.getWidth()) { 
        		direction *= -1;
        	

               }
        	
	     	g2.translate(0, img.getHeight());
     
            
	      g2.drawImage(img, x, -img.getHeight(), this); 
	     		
	      
	    }
}

