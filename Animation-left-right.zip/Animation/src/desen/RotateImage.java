package desen;


import java.awt.*;
import javax.swing.JFrame;

public class RotateImage {
	  public RotateImage() {
	        EventQueue.invokeLater(new Runnable() {
	            @Override
	            public void run() {
	                JFrame frame = new JFrame("Imagine");
	                frame.add(new animationPanel());
	                frame.pack();
	                frame.setLocationRelativeTo(null);
	                frame.setResizable(false);
	                frame.setVisible(true);
	                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	            }
	        });
	    }
	    
	    public static void main(String[] args) {
	        new RotateImage();
	    }
}
